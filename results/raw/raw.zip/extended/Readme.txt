brute test with 300 requests. JVM fixed to 'open'.
